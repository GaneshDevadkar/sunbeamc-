#include<stdio.h>

int main()
{
    printf("\n Good morning ...");
    return 0;
}
//g++ demo1.cpp