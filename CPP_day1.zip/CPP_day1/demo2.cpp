#include<stdio.h>

//void printMessage();
//Inline Function
inline void printMessage()
{
    printf("\n Hello PH27 .. good morning .. :)");
}
int main()
{
    printMessage();
    printMessage();
    printMessage();
    return 0;
}

